import jieba
from collections import Counter
import math
import re

def remove_punctuation(line):
    rule = re.compile(r"[^a-zA-Z0-9\u4e00-\u9fa5]")
    line = rule.sub('',line)
    return line

def is_contain_chinese(check_str):
    """
    判断字符串中是否包含中文
    :param check_str: {str} 需要检测的字符串
    :return: {bool} 包含返回True， 不包含返回False
    """
    for ch in check_str:
        if u'\u4e00' <= ch <= u'\u9fff':
            return True
    return False

with open("预处理后的文本.txt", "r", encoding="utf-8") as f:
    corpus = [eve.strip("\n") for eve in f]
# 3-gram
def combine3gram(cutword_list):
    if len(cutword_list) <= 2:
        return []
    res = []
    for i in range(len(cutword_list)-2):
        res.append(cutword_list[i] + cutword_list[i+1] + " " + cutword_list[i+2] )
    return res
token_3gram = []
for para in corpus:
    cutword_list = jieba.lcut(para)
    # cutword_list = [removePunctuation(eve) for eve in cutword_list if removePunctuation(eve) != ""]
    token_3gram += combine3gram(cutword_list)
# 3-gram的频率统计
token_3gram_num = len(token_3gram)
ct3 = Counter(token_3gram)
vocab3 = ct3.most_common()
# print(vocab3[:20])
# 3-gram相同句首两个词语的频率统计
same_2st_word = [eve.split(" ")[0] for eve in token_3gram]
assert token_3gram_num == len(same_2st_word)
ct_2st = Counter(same_2st_word)
vocab_2st = dict(ct_2st.most_common())
entropy_3gram = 0
for eve in vocab3:
    p_xyz = eve[1]/token_3gram_num
    first_2word = eve[0].split(" ")[0]
    entropy_3gram += -p_xyz*math.log(eve[1]/vocab_2st[first_2word], 2)
L = [[0]*2 for i in range(10)]
i = 0
j = 1
while True:
    L[i][0] = vocab3[j][0]
    L[i][1] = vocab3[j][1]
    L[i][0] = L[i][0].replace(' ', '')
    L[i][0] = remove_punctuation(L[i][0])
    if not is_contain_chinese(L[i][0]):
        j = j+1
        continue
    i = i+1
    j = j+1
    if i == 10:
        break
print("词库总词数：", token_3gram_num, " ", "不同词的个数：", len(vocab3))
print("出现频率前10的3-gram词语：", L)
print("entropy_3gram:", entropy_3gram)

